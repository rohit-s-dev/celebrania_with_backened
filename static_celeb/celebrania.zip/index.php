
<?php  $title = "Celebrania:: Home";
include "inc/header.inc.php"; ?>
<?php include "inc/logo-intro.inc.php"; ?>
<?php include "inc/home-slider.inc.php"; ?>
<?php include "inc/nav.inc.php"; ?>
<?php include "inc/footer.inc.php"; ?>