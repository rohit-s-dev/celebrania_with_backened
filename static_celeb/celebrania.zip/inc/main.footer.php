<footer class="main_footer">
    <div class="container">
        <div class="row">
            <div class="col-md-4 footer_left">
                    <span class="">All copyright &copy; 2018 Reserved</span>
            </div>
            
            <div class="col-md-4">
                <ul class="footer_middle">
                    <li><a href="">Home</a></li>
                    <li><a href="">Our Works</a></li>
                    <li><a href="">Careers</a></li>
                    <li><a href="">Contact Us</a></li>
                </ul>
            </div>

            <div class="col-md-4 footer_right">
                <a href="https://www.facebook.com/celebraniaevent/" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                <a href="https://linkedin.com/in/celebrania-event-6bbb46172" target="_blank"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
                <a href="https://instagram.com/celebraniaevent?utm_source=ig_profile_share&gshid=1a1dfv152yplz" target="_blank"><i class="fa fa-instagram" aria-hidden="true"></i></a>
            </div>
        </div>
    </div>
</footer>