<div id="intro">
    <div id="logo-holder">
    </div>
</div>