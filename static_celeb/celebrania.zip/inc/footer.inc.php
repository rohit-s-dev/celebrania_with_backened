<script data-global="true" src="js/combined.min.js" type="text/javascript"></script>
<script src="js/home.min.js" type="text/javascript"></script>
<script src="js/simple-lightbox.js" type="text/javascript"></script>
<script src="js/jportilio.min.js" type="text/javascript"></script>
<script src="js/main.js" type="text/javascript"></script>
</body>
</html>
