<?php $title = "Celebrania:: Who are we"; 
include "inc/header.inc.php"; ?>
<?php include "inc/m-nav.inc.php"; ?>

<!-- <section class="our_works_d">
    <div class="container">
        <div class="row">
            <div class="col-lg-8">
                <h3 class="our_works_d_title">Our Works</h3>
            </div>
            <div class="col-lg-4"></div>
        </div>
    </div>
</section> -->


<section class="our_works_p">
    <div class="container">
        <div class="row no-gutters gallery">
            <div class="col-lg-4 col-md-4 col-sm-4 text-center mbb10">
                <div class="img-box">
                    <a href="images/our_works/1.jpeg"></a>
                    <img src="images/our_works/1.jpeg" alt="">
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-4 text-center mbb10">
                <div class="img-box">
                    <img src="images/our_works/2.jpeg" alt="">
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-4 text-center mbb10">
                <div class="img-box">
                    <img src="images/our_works/3.jpeg" alt="">
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-4 text-center mbb10">
                <div class="img-box">
                    <img src="images/our_works/4.jpeg" alt="">
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-4 text-center mbb10">
                <div class="img-box">
                    <img src="images/our_works/7.jpeg" alt="">
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-4 text-center mbb10">
                <div class="img-box">
                    <img src="images/our_works/8.jpeg" alt="">
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-4 text-center mbb10">
                <div class="img-box">
                    <img src="images/our_works/9.jpeg" alt="">
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-4 text-center mbb10">
                <div class="img-box">
                    <img src="images/our_works/10.jpeg" alt="">
                </div>
            </div>
        </div>
    </div>
</section>

<?php include "inc/main.footer.php"; ?>
<?php include "inc/footer.inc.php"; ?>